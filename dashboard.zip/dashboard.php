<!DOCTYPE html>
<html>
<?php
//include auth_session.php file on all user panel pages
include("auth_session.php");
?>
	<title></title>
	<link rel="stylesheet" type="text/css" href="dboard.css">
</head>
<body>
   <div class="header"></div>
   <div class="container"></div>
<div class="leftcontainer"></div>
<div class="dashbox">
	    <p>Welcome <?php echo $_SESSION['username']; ?></p>
        <p>Dashboard</p>
        <p><a href="logout.php">Logout</a></p>
</div>
<div class="linkbox">
<ul>
  <li><a href="Coursereg.php">Course Registration</a></li>
  <li><a href="findstudent.php">Find Student</a></li>
  <li><a></a></li>
</ul>
</div>
<div class="operationsection"></div>
<div class="writesection">
	<h4 align="center">WELCOME TO IMONIKHES TECH ACADEMY</h4>
  <p><font size="+2"><font color="cyan">The Tech Academy you get the best in programming , development , consultancy and many more......with
   professionals and qualified tech trainers and coaches to coach you to the maximum height with tremendous knowledge
   and great skills. 
   our trainers and coaches are qualified tech professionals from different universities in the world such as harvard university,oxford university,university of cambridge ,university of BC,canada and many more.
      Give us a try today and you will not regret joining us but rejoice that you were trained and impacted with great
      knowledge.
    register today and become a world class web developer,frontend developer, backend developer ,software developer and any kind of developer you wish to be .</font></font>
  </p>
</div>
<div class="marqueelink"><marquee direction="left"><font size="+2"><font color="cyan">Welcome to your dashboard.......</font><font color="yellow">click on the Course Registration to  Register a Tech Course and</font><font color="pink"> to check your name click on the Find Student</font> </font></font></marquee>

</div>
<div class="footer"><p align="center"><font color="white">Copyright &copy 2020</font></p></div> 
</body>    
</html>