<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="coursereg.css">
</head>
<body>
<div class="header">
</div>
<div class="welcomebar"></div>
<div class="linkbar">
	<ul>
  <li><a href="dashboard.php">BACK TO DASHBOARD</a></li>
</ul>
</div>
<div class="container">
	 <form action=""  method="POST">
          <h2><font color="+4"><font color="yellow">REGISTER COURSE HERE</font></font></h2>
    	<table>
    		<tr> 
    			<td><font color="+4"><font color="white">firstname</font></font></td>
    			<td><input type="text" name="firstname" required="required"></td>
    		</tr>
    		<tr>
    			<td><font color="+4"><font color="white">middlename</font></font></td>
    			<td><input type="text" name="middlename" required="required"></td>
    		</tr>

    		<tr>
    			<td><font color="+4"><font color="white">lastname</font></font></td>
    			<td><input type="text" name="lastname" required="required"></td>
    		</tr>
    		 <tr>
    			<td><font color="+4"><font color="white">username</font></font></td>
    			<td><input type="text" name="username" required="required"></td>
    		</tr>
        <tr>
          <td><font color="+4"><font color="white">email</font></font></td>
          <td><input type="text" name="email" required="required"></td>
        </tr>
         <tr>
    			<td><font color="+4"><font color="white">course</font></font></td>
    			<td><input type="text" name="course" required="required"></td>
    		</tr>
    		<tr>
    			<td><p align="right"><input type="submit" name="register" value="register"></p></td>
    		</tr>
         </table>
    	 </form>
    	 <?php
    	 // check if submitted ,insert data into items table
             if (isset($_POST['register'])) {
             	  $firstname = $_POST['firstname'];
             	  $middlename = $_POST['middlename'];
             	  $lastname = $_POST['lastname'];
             	  $username = $_POST['username'];
             	  $email = $_POST['email'];
             	  $course = $_POST['course'];
 //include database connection file 
 include_once('db.php');

 // insert items data into table
    
 $result = mysqli_query($con,"INSERT INTO student_course(firstname,middlename,lastname,username,email,course)VALUES('$firstname','$middlename','$lastname','$username','$email','$course');");

    // show message when item added 
    echo "<font color='pink'>Registered Successfully</font>";
  }
?>
</div>
<div class="footer"><p align="center"><font color="white">Copyright &copy 2020</font></p></div>

</body>
</html>