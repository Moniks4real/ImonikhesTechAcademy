<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="index.css">
</head>
<body>
  <div class="header"></div> 
  <div class="welcomebar">WELCOME TO IMONIKHES TECH ACADEMY</div>
  <div class="linkbar">
 <ul>
  <li><a href="register.php">Register</a></li>
  <li><a href="Course.html">Courses</a></li>
  <li><a href="Contact.html">Contact Us</a></li>
  <li><a href="About.html">About Us</a></li>
</ul>
  </div>
<div class="container">
	<?php echo"<font size='+4'>You have Registered Successfully</font>";?><br>
	<?php echo "<font size='+4'>Click <a href='login.php'>Login</a></font>";?><br>
</div>
<div class="footer"><p align="center"><font color="white">Copyright &copy 2020</font></p></div>  
</body>
</html>