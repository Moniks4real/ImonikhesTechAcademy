<?php
// creat database connection using db file
include_once("db.php");

// fetch all item data from database 

$result = mysqli_query($con,"SELECT * FROM student_course ORDER BY ref_id ASC");
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="findstudent.css">
</head>
<div class="header"><h1 align="center">
    <font color="red"><font size="+4"><b>NAMES OF REGISTERED STUDENTS HERE</b></font></font></h1>
</div>
<div class="welcomebar"></div>
<div class="linkbar">
    <ul>
  <li><a href="dashboard.php">BACK TO DASHBOARD</a></li>
</ul>
</div>
<body bgcolor="black">
<table border="5" width="auto"  style="background-color:black;color:cyan;">
	<tr>
	<th>REF_ID</th><th>FIRSTNAME</th><th>MIDDLENAME</th><th>LASTNAME</th><th>USERNAME</th><th>EMAIL</th><th>COURSE</th>
	</tr>
    <?php
        while($row=mysqli_fetch_array($result)){
         echo "<tr>";
         echo "<td>".$row['ref_id']."</td>";
         echo "<td>".$row['firstname']."</td>";
         echo "<td>".$row['middlename']."</td>";
         echo "<td>".$row['lastname']."</td>";
         echo "<td>".$row['username']."</td>";
         echo "<td>".$row['email']."</td>";
         echo "<td>".$row['course']."</td>";
         echo "</tr>";
 }
?>	
</table>
</body>
</html>