<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<?php
    require('db.php');
    // When form submitted, insert values into the database.
    if (isset($_REQUEST['username'])) {
        // removes backslashes
        $username = stripslashes($_REQUEST['username']);
        //escapes special characters in a string
        $username = mysqli_real_escape_string($con, $username);
        $firstname = stripslashes($_REQUEST['firstname']);
        $firstname = mysqli_real_escape_string($con, $firstname);
        $middlename = stripslashes($_REQUEST['middlename']);
        $middlename = mysqli_real_escape_string($con, $middlename);
        $lastname = stripslashes($_REQUEST['lastname']);
        $lastname = mysqli_real_escape_string($con, $lastname);
        $email    = stripslashes($_REQUEST['email']);
        $email    = mysqli_real_escape_string($con, $email);
        $password = stripslashes($_REQUEST['password']);
        $password = mysqli_real_escape_string($con, $password);
        $query    = "INSERT into `student_tb` (firstname,middlename,lastname,username, password, email)
                     VALUES ('$firstname','$middlename','$lastname','$username', '" . md5($password) . "', '$email')";
        $result = mysqli_query($con,$query);
            if ($result) {
            header("Location:index.php");
                } else {
            header("Location:register.php");
        }
    } else {
?>
  <div class="header"></div> 
  <div class="welcomebar">WELCOME TO IMONIKHES TECH ACADEMY</div>
  <div class="linkbar">
  	<ul>
  <li><a href="register.php">Register</a></li>
  <li><a href="Course.html">Courses</a></li>
  <li><a href="About.html">About Us</a></li>
  <li><a href="Contact.html">Contact Us</a></li>
</ul>
  </div> 
<div class="container">
	<form action=""  method="post">
		<h4 align="right"><font color="red">SIGNUP HERE</font></h4>
        <p align="right">
         <div>
         <p align="right"><b><font color="red">firstname</font></b>
            <input type="text" name="firstname" required="
            required">
              <br></p>
         </div>
         <div>
         <p align="right"><b><font color="red">middlename</font></b>
         	<input type="text" name="middlename" required="required">
         <br></p>
         </div>
         <div>
         	<p align="right">
         	<b><font color="red">lastname</font></b>
         	<input type="text" name="lastname" required="required"><br>
         </p>
         </div>
         <div>
         	<p align="right">
         	<b><font color="red">username</font></b>
         	<input type="text" name="username" required="required"><br>
         </p>
         </div>
         <div>
         	<p align="right">
         	<b><font color="red">email</font></b>
         	<input type="email" name="email" required="required"><br>
         </p>
         </div>
         <div>
         	<p align="right">
         	<b><font color="red">password</font></b>
         	<input type="password" name="password" required="required"><br>
         </p>
         </div>
         <div>
         	<p align="right">
         	<b><input type="submit" name="submit" value="Signup"></b><br>
         	<font color="blue"><b>Already have an account?| <a href="login.php"> Login here </a></b></font>
         </p>
         </div>
     </p>
	</form>
</div>
<div class="footer"><p align="center"><font color="white">Copyright &copy 2020</font></p></div>
<?php
    }
?>
</body>
</html>