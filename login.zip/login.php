<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <?php
    require('db.php');
    session_start();
    // When form submitted, check and create user session.
    if (isset($_POST['username'])) {
        $username = stripslashes($_REQUEST['username']);    // removes backslashes
        $username = mysqli_real_escape_string($con, $username);
        $password = stripslashes($_REQUEST['password']);
        $password = mysqli_real_escape_string($con, $password);
        // Check user is exist in the database
        $query    = "SELECT * FROM `student_tb` WHERE username='$username'
                     AND password='" . md5($password) . "'";
        $result = mysqli_query($con, $query) or die(mysql_error());
        $rows = mysqli_num_rows($result);
        if ($rows == 1) {
            $_SESSION['username'] = $username;
            // Redirect to user dashboard page
            header("Location:dashboard.php");
        } else{
            header("Location:register.php");
        }
    } else {
?>
  <div class="header"></div> 
  <div class="welcomebar">WELCOME TO IMONIKHES TECH ACADEMY</div>
  <div class="linkbar">
    <ul>
  <li><a href="register.php">Register</a></li>
  <li><a href="Course.html">Courses</a></li>
  <li><a href="Contact.html">Contact Us</a></li>
  <li><a href="About.html">About Us</a></li>
</ul>
  </div>
<div class="container">
    <form action=""  method="post">
        <h4 align="right"><font color="red">LOGIN HERE</font></h4>
        <p align="right">
         <div>
            <p align="right">
            <label><b><font color="red">username</font></b></label>
            <input type="text" name="username"><br>
         </p>
         </div>
         <div>
            <p align="right">
            <label><b><font color="red">password</font></b></label>
            <input type="password" name="password"><br>
         </p>
         </div>
         <div>
            <p align="right">
            <input type="submit" name="submit" value="login"><br>
            <font color="blue"><b>Don't have an account| <a href="register.php"> Signup here </a></b></font>
         </p>
         </div>
     </p>
    </form>
</div>
<div class="footer"><p align="center"><font color="white">Copyright &copy 2020</font></p></div>  
<?php
    }
?>
</body>
</html>